# 🎓 LearnFlow — Online Learning Platform

[![CI/CD](https://github.com/yourusername/learnflow/actions/workflows/ci.yml/badge.svg)](https://github.com/yourusername/learnflow/actions)
[![Python](https://img.shields.io/badge/Python-3.11-blue.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110-green.svg)](https://fastapi.tiangolo.com)
[![React](https://img.shields.io/badge/React-18-61DAFB.svg)](https://react.dev)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A full-stack online learning platform with course management, progress tracking, and JWT authentication. Built with **FastAPI**, **PostgreSQL**, and **React**.

---

## ✨ Features

- 🔐 **JWT Authentication** — register, login, token refresh
- 📚 **Course Catalog** — browse, filter, and enroll in courses
- 📖 **Lesson Player** — structured lessons with progress tracking
- 📊 **Student Dashboard** — visualize learning progress per course
- 🛠️ **Instructor Panel** — create and manage courses & lessons
- ✅ **Test Coverage** — 80%+ with pytest
- 📄 **Auto API Docs** — Swagger UI at `/docs`

---

## 🏗️ Architecture

```
learnflow/
├── backend/                  # FastAPI application
│   ├── app/
│   │   ├── api/v1/endpoints/ # Route handlers
│   │   ├── core/             # Config, security, deps
│   │   ├── db/               # Database session
│   │   ├── models/           # SQLAlchemy ORM models
│   │   ├── schemas/          # Pydantic schemas
│   │   ├── services/         # Business logic layer
│   │   └── tests/            # Pytest test suite
│   └── alembic/              # DB migrations
└── frontend/                 # React + Vite application
    └── src/
        ├── components/       # Reusable UI components
        ├── pages/            # Route-level pages
        ├── store/            # Zustand state management
        ├── api/              # Axios API client
        └── hooks/            # Custom React hooks
```

---

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- Node.js 18+
- PostgreSQL 15+
- Docker & Docker Compose (optional)

### Option 1 — Docker (Recommended)

```bash
git clone https://github.com/yourusername/learnflow.git
cd learnflow
cp backend/.env.example backend/.env
docker compose up --build
```

Open:
- Frontend: http://localhost:5173
- API Docs: http://localhost:8000/docs

---

### Option 2 — Manual Setup

**Backend:**

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env            # fill in your DB credentials
alembic upgrade head            # run migrations
python seed.py                  # optional: seed demo data
uvicorn app.main:app --reload
```

**Frontend:**

```bash
cd frontend
npm install
cp .env.example .env.local
npm run dev
```

---

## 🧪 Running Tests

```bash
cd backend
pytest --cov=app --cov-report=term-missing
```

Expected output:
```
---------- coverage: 83% ----------
PASSED tests/test_auth.py::test_register
PASSED tests/test_auth.py::test_login
PASSED tests/test_courses.py::test_list_courses
PASSED tests/test_courses.py::test_enroll
PASSED tests/test_progress.py::test_complete_lesson
...
```

---

## 📡 API Endpoints

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | `/api/v1/auth/register` | Register new user | — |
| POST | `/api/v1/auth/login` | Login, get JWT | — |
| GET | `/api/v1/courses` | List all courses | — |
| GET | `/api/v1/courses/{id}` | Course detail + lessons | — |
| POST | `/api/v1/courses` | Create course | Instructor |
| POST | `/api/v1/enrollments` | Enroll in course | Student |
| GET | `/api/v1/enrollments/me` | My enrollments | Student |
| PATCH | `/api/v1/progress/{lesson_id}` | Mark lesson complete | Student |
| GET | `/api/v1/users/me` | Current user profile | Any |

Full interactive docs: **http://localhost:8000/docs**

---

## 🗄️ Database Schema

```
users ──< enrollments >── courses ──< lessons
                              │
                         categories
users ──< progress >── lessons
```

---

## 🔧 Environment Variables

**backend/.env**
```env
DATABASE_URL=postgresql://user:password@localhost:5432/learnflow
SECRET_KEY=your-secret-key-min-32-chars
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
ENVIRONMENT=development
```

**frontend/.env.local**
```env
VITE_API_URL=http://localhost:8000
```

---

## 🤝 Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Commit with conventional commits: `git commit -m "feat: add quiz feature"`
4. Push and open a Pull Request

---

## 📄 License

MIT © 2024 Your Name
