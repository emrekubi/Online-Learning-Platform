import { Link } from 'react-router-dom'
import type { CourseSummary } from '../../types'

const LEVEL_COLORS: Record<string, string> = {
  beginner: 'bg-green-100 text-green-700',
  intermediate: 'bg-yellow-100 text-yellow-700',
  advanced: 'bg-red-100 text-red-700',
}

interface Props {
  course: CourseSummary
}

export default function CourseCard({ course }: Props) {
  const levelColor = LEVEL_COLORS[course.level] ?? 'bg-slate-100 text-slate-700'

  return (
    <Link
      to={`/courses/${course.id}`}
      className="card group flex flex-col gap-3 hover:shadow-md transition-shadow"
    >
      {course.thumbnail_url ? (
        <img
          src={course.thumbnail_url}
          alt={course.title}
          className="h-40 w-full rounded-lg object-cover"
        />
      ) : (
        <div className="h-40 w-full rounded-lg bg-gradient-to-br from-brand-100 to-brand-200 flex items-center justify-center text-4xl">
          📚
        </div>
      )}

      <div className="flex items-center justify-between">
        <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${levelColor}`}>
          {course.level}
        </span>
      </div>

      <h3 className="font-semibold text-slate-900 group-hover:text-brand-700 transition-colors line-clamp-2">
        {course.title}
      </h3>
      <p className="text-sm text-slate-500 line-clamp-2">{course.description}</p>
    </Link>
  )
}
