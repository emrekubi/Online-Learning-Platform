import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { coursesApi, enrollmentsApi, progressApi } from '../api'
import ProgressBar from '../components/ui/ProgressBar'
import { useAuthStore } from '../store/authStore'
import type { Course, CourseProgress } from '../types'

export default function CoursePage() {
  const { id } = useParams<{ id: string }>()
  const courseId = Number(id)
  const { user } = useAuthStore()
  const navigate = useNavigate()

  const [course, setCourse] = useState<Course | null>(null)
  const [progress, setProgress] = useState<CourseProgress | null>(null)
  const [completedIds, setCompletedIds] = useState<Set<number>>(new Set())
  const [enrolled, setEnrolled] = useState(false)
  const [loading, setLoading] = useState(true)
  const [enrolling, setEnrolling] = useState(false)
  const [activeLesson, setActiveLesson] = useState<number | null>(null)

  useEffect(() => {
    coursesApi.get(courseId).then(setCourse).catch(console.error).finally(() => setLoading(false))
  }, [courseId])

  useEffect(() => {
    if (!user) return
    coursesApi
      .getProgress(courseId)
      .then((p) => {
        setProgress(p)
        setEnrolled(true)
      })
      .catch(() => setEnrolled(false))
  }, [courseId, user])

  const handleEnroll = async () => {
    if (!user) { navigate('/login'); return }
    setEnrolling(true)
    try {
      await enrollmentsApi.enroll(courseId)
      setEnrolled(true)
      const p = await coursesApi.getProgress(courseId)
      setProgress(p)
    } finally {
      setEnrolling(false)
    }
  }

  const handleComplete = async (lessonId: number) => {
    await progressApi.completeLesson(lessonId)
    setCompletedIds((prev) => new Set([...prev, lessonId]))
    const p = await coursesApi.getProgress(courseId)
    setProgress(p)
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-12 space-y-4">
        <div className="h-8 w-2/3 animate-pulse rounded bg-slate-200" />
        <div className="h-4 w-full animate-pulse rounded bg-slate-100" />
        <div className="h-4 w-5/6 animate-pulse rounded bg-slate-100" />
      </div>
    )
  }

  if (!course) {
    return <div className="py-20 text-center text-slate-400">Course not found.</div>
  }

  const activeLessonData = course.lessons.find((l) => l.id === activeLesson)

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="grid gap-8 lg:grid-cols-3">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Header */}
          <div>
            <span className="inline-block mb-2 rounded-full bg-brand-100 px-3 py-1 text-xs font-medium text-brand-700 capitalize">
              {course.level}
            </span>
            <h1 className="text-3xl font-bold text-slate-900">{course.title}</h1>
            <p className="mt-3 text-slate-600 leading-relaxed">{course.description}</p>
          </div>

          {/* Progress bar (enrolled users) */}
          {enrolled && progress && (
            <div className="card">
              <h3 className="mb-3 text-sm font-semibold text-slate-700">Your progress</h3>
              <ProgressBar percent={progress.percent} label={`${progress.completed_lessons} / ${progress.total_lessons} lessons completed`} />
            </div>
          )}

          {/* Active lesson viewer */}
          {activeLessonData && (
            <div className="card space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-slate-900">{activeLessonData.title}</h2>
                <span className="text-xs text-slate-400">{activeLessonData.duration_minutes} min</span>
              </div>

              {/* Placeholder video area */}
              <div className="flex h-48 items-center justify-center rounded-lg bg-slate-100 text-slate-400">
                <div className="text-center">
                  <div className="text-4xl mb-2">▶️</div>
                  <p className="text-sm">Video player would render here</p>
                </div>
              </div>

              <p className="text-sm text-slate-600 leading-relaxed">
                {/* In real app, this would be rich markdown/HTML content */}
                {activeLessonData.title} — lesson content goes here. In production this field stores
                Markdown that gets rendered with a library like react-markdown.
              </p>

              {enrolled && !completedIds.has(activeLessonData.id) && (
                <button
                  onClick={() => handleComplete(activeLessonData.id)}
                  className="btn-primary"
                >
                  ✓ Mark as complete
                </button>
              )}
              {completedIds.has(activeLessonData.id) && (
                <p className="text-sm font-medium text-green-600">✓ Completed</p>
              )}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Enroll card */}
          <div className="card space-y-4">
            {course.thumbnail_url ? (
              <img src={course.thumbnail_url} alt={course.title} className="w-full rounded-lg object-cover h-36" />
            ) : (
              <div className="flex h-36 items-center justify-center rounded-lg bg-gradient-to-br from-brand-100 to-brand-200 text-5xl">
                📚
              </div>
            )}

            <div className="space-y-2 text-sm text-slate-600">
              <div className="flex justify-between">
                <span>Lessons</span>
                <span className="font-medium">{course.lessons.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Level</span>
                <span className="font-medium capitalize">{course.level}</span>
              </div>
              {course.category && (
                <div className="flex justify-between">
                  <span>Category</span>
                  <span className="font-medium">{course.category.name}</span>
                </div>
              )}
            </div>

            {!enrolled ? (
              <button onClick={handleEnroll} className="btn-primary w-full" disabled={enrolling}>
                {enrolling ? 'Enrolling…' : 'Enroll for free'}
              </button>
            ) : (
              <div className="rounded-lg bg-green-50 py-2 text-center text-sm font-medium text-green-700">
                ✓ Enrolled
              </div>
            )}
          </div>

          {/* Lesson list */}
          {course.lessons.length > 0 && (
            <div className="card">
              <h3 className="mb-3 text-sm font-semibold text-slate-700">
                Curriculum · {course.lessons.length} lessons
              </h3>
              <ul className="space-y-1">
                {course.lessons.map((lesson) => {
                  const done = completedIds.has(lesson.id)
                  const isActive = activeLesson === lesson.id
                  return (
                    <li key={lesson.id}>
                      <button
                        onClick={() => enrolled && setActiveLesson(lesson.id)}
                        className={`w-full flex items-center gap-3 rounded-lg px-3 py-2 text-left text-sm transition
                          ${isActive ? 'bg-brand-50 text-brand-700 font-medium' : 'hover:bg-slate-50 text-slate-700'}
                          ${!enrolled ? 'cursor-not-allowed opacity-60' : ''}`}
                        disabled={!enrolled}
                        title={enrolled ? '' : 'Enroll to access lessons'}
                      >
                        <span className="text-base">
                          {done ? '✅' : enrolled ? '▶' : '🔒'}
                        </span>
                        <span className="flex-1 truncate">{lesson.title}</span>
                        <span className="text-xs text-slate-400">{lesson.duration_minutes}m</span>
                      </button>
                    </li>
                  )
                })}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
