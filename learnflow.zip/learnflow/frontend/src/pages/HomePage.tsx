import { useEffect, useState } from 'react'
import { coursesApi } from '../api'
import CourseCard from '../components/course/CourseCard'
import type { CourseSummary } from '../types'

export default function HomePage() {
  const [courses, setCourses] = useState<CourseSummary[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    coursesApi
      .list()
      .then(setCourses)
      .catch(() => setError('Failed to load courses'))
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      {/* Hero */}
      <div className="mb-12 text-center">
        <h1 className="mb-4 text-4xl font-bold tracking-tight text-slate-900">
          Learn at your own pace
        </h1>
        <p className="text-lg text-slate-500">
          Explore courses built by expert instructors. Track your progress, lesson by lesson.
        </p>
      </div>

      {/* Course grid */}
      {loading && (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="card h-64 animate-pulse bg-slate-100" />
          ))}
        </div>
      )}

      {error && (
        <div className="rounded-lg bg-red-50 p-4 text-center text-red-600">{error}</div>
      )}

      {!loading && !error && courses.length === 0 && (
        <div className="rounded-xl border-2 border-dashed border-slate-200 p-16 text-center text-slate-400">
          <div className="text-5xl mb-4">📭</div>
          <p className="font-medium">No courses yet.</p>
          <p className="text-sm mt-1">Run <code>python seed.py</code> to add demo content.</p>
        </div>
      )}

      {!loading && !error && courses.length > 0 && (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {courses.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      )}
    </div>
  )
}
