import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { coursesApi, enrollmentsApi } from '../api'
import ProgressBar from '../components/ui/ProgressBar'
import { useAuthStore } from '../store/authStore'
import type { CourseProgress, Enrollment } from '../types'

export default function DashboardPage() {
  const { user } = useAuthStore()
  const [enrollments, setEnrollments] = useState<Enrollment[]>([])
  const [progressMap, setProgressMap] = useState<Record<number, CourseProgress>>({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    enrollmentsApi
      .myEnrollments()
      .then(async (enrs) => {
        setEnrollments(enrs)
        // Fetch progress for each enrolled course in parallel
        const results = await Promise.allSettled(
          enrs.map((e) => coursesApi.getProgress(e.course_id))
        )
        const map: Record<number, CourseProgress> = {}
        results.forEach((r, i) => {
          if (r.status === 'fulfilled') {
            map[enrs[i].course_id] = r.value
          }
        })
        setProgressMap(map)
      })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [])

  const totalCourses = enrollments.length
  const completedCourses = Object.values(progressMap).filter((p) => p.percent === 100).length
  const overallPercent =
    totalCourses === 0
      ? 0
      : Math.round(
          Object.values(progressMap).reduce((sum, p) => sum + p.percent, 0) / totalCourses
        )

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 space-y-8">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl font-bold text-slate-900">
          Welcome back, {user?.full_name?.split(' ')[0]} 👋
        </h1>
        <p className="mt-1 text-slate-500">Here's your learning overview.</p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Enrolled courses" value={totalCourses} icon="📚" />
        <StatCard label="Completed" value={completedCourses} icon="✅" />
        <StatCard label="Avg. progress" value={`${overallPercent}%`} icon="📈" />
      </div>

      {/* Course list */}
      <div>
        <h2 className="mb-4 text-lg font-semibold text-slate-800">My courses</h2>

        {loading && (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card h-24 animate-pulse bg-slate-100" />
            ))}
          </div>
        )}

        {!loading && enrollments.length === 0 && (
          <div className="card text-center py-12 text-slate-400">
            <div className="text-5xl mb-3">🎒</div>
            <p className="font-medium text-slate-600">You haven't enrolled in any courses yet.</p>
            <Link to="/" className="mt-4 inline-block btn-primary">
              Browse courses
            </Link>
          </div>
        )}

        {!loading && enrollments.length > 0 && (
          <div className="space-y-3">
            {enrollments.map((enrollment) => {
              const prog = progressMap[enrollment.course_id]
              const { course } = enrollment
              return (
                <Link
                  key={enrollment.id}
                  to={`/courses/${course.id}`}
                  className="card flex items-center gap-4 hover:shadow-md transition-shadow group"
                >
                  {/* Thumbnail */}
                  {course.thumbnail_url ? (
                    <img
                      src={course.thumbnail_url}
                      alt={course.title}
                      className="h-16 w-24 flex-shrink-0 rounded-lg object-cover"
                    />
                  ) : (
                    <div className="flex h-16 w-24 flex-shrink-0 items-center justify-center rounded-lg bg-brand-100 text-3xl">
                      📚
                    </div>
                  )}

                  {/* Info */}
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-semibold text-slate-900 group-hover:text-brand-700 transition-colors truncate">
                        {course.title}
                      </h3>
                      <span className="flex-shrink-0 text-xs capitalize text-slate-400 bg-slate-100 rounded-full px-2 py-0.5">
                        {course.level}
                      </span>
                    </div>

                    {prog ? (
                      <ProgressBar
                        percent={prog.percent}
                        label={`${prog.completed_lessons} / ${prog.total_lessons} lessons`}
                      />
                    ) : (
                      <div className="h-2 w-full rounded-full bg-slate-100" />
                    )}
                  </div>
                </Link>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

function StatCard({ label, value, icon }: { label: string; value: string | number; icon: string }) {
  return (
    <div className="card flex items-center gap-4">
      <span className="text-3xl">{icon}</span>
      <div>
        <p className="text-2xl font-bold text-slate-900">{value}</p>
        <p className="text-sm text-slate-500">{label}</p>
      </div>
    </div>
  )
}
