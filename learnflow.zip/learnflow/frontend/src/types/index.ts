export interface User {
  id: number
  email: string
  full_name: string
  role: 'student' | 'instructor' | 'admin'
  created_at: string
}

export interface Category {
  id: number
  name: string
  slug: string
}

export interface LessonSummary {
  id: number
  title: string
  order: number
  duration_minutes: number
}

export interface Lesson extends LessonSummary {
  content: string
  video_url: string | null
}

export interface CourseSummary {
  id: number
  title: string
  description: string
  thumbnail_url: string | null
  level: string
  instructor_id: number
}

export interface Course extends CourseSummary {
  created_at: string
  category: Category | null
  lessons: LessonSummary[]
}

export interface Enrollment {
  id: number
  course_id: number
  student_id: number
  enrolled_at: string
  course: CourseSummary
}

export interface CourseProgress {
  course_id: number
  total_lessons: number
  completed_lessons: number
  percent: number
}

export interface Token {
  access_token: string
  token_type: string
}
