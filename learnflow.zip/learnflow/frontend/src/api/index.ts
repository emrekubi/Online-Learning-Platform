import type { Course, CourseSummary, CourseProgress, Enrollment, Lesson, Token, User } from '../types'
import api from './client'

// ── Auth ────────────────────────────────────────────────────────────────────

export const authApi = {
  register: (data: { email: string; full_name: string; password: string; role: string }) =>
    api.post<User>('/api/v1/auth/register', data).then(r => r.data),

  login: (email: string, password: string) => {
    const form = new URLSearchParams({ username: email, password })
    return api.post<Token>('/api/v1/auth/login', form).then(r => r.data)
  },

  me: () => api.get<User>('/api/v1/auth/me').then(r => r.data),
}

// ── Courses ─────────────────────────────────────────────────────────────────

export const coursesApi = {
  list: (skip = 0, limit = 20) =>
    api.get<CourseSummary[]>('/api/v1/courses', { params: { skip, limit } }).then(r => r.data),

  get: (id: number) =>
    api.get<Course>(`/api/v1/courses/${id}`).then(r => r.data),

  create: (data: { title: string; description: string; level: string }) =>
    api.post<Course>('/api/v1/courses', data).then(r => r.data),

  addLesson: (courseId: number, data: { title: string; content: string; order: number; duration_minutes: number }) =>
    api.post<Lesson>(`/api/v1/courses/${courseId}/lessons`, data).then(r => r.data),

  getProgress: (courseId: number) =>
    api.get<CourseProgress>(`/api/v1/courses/${courseId}/progress`).then(r => r.data),
}

// ── Enrollments ─────────────────────────────────────────────────────────────

export const enrollmentsApi = {
  enroll: (courseId: number) =>
    api.post<Enrollment>('/api/v1/enrollments', { course_id: courseId }).then(r => r.data),

  myEnrollments: () =>
    api.get<Enrollment[]>('/api/v1/enrollments/me').then(r => r.data),
}

// ── Progress ────────────────────────────────────────────────────────────────

export const progressApi = {
  completeLesson: (lessonId: number) =>
    api.patch(`/api/v1/progress/${lessonId}`).then(r => r.data),
}
