"""
Seed the database with demo data.
Run: python seed.py
"""
from app.db.session import SessionLocal, Base
from app.core.config import settings
from sqlalchemy import create_engine
from app.models.user import User
from app.models.course import Category, Course, Lesson
from app.models.enrollment import Enrollment
from app.core.security import hash_password

engine = create_engine(settings.DATABASE_URL)
Base.metadata.create_all(bind=engine)
db = SessionLocal()

print("🌱 Seeding database...")

# Users
instructor = User(
    email="instructor@learnflow.dev",
    full_name="Alex Johnson",
    hashed_password=hash_password("instructor123"),
    role="instructor",
)
student = User(
    email="student@learnflow.dev",
    full_name="Maria Garcia",
    hashed_password=hash_password("student123"),
    role="student",
)
db.add_all([instructor, student])
db.flush()

# Categories
cat_python = Category(name="Python", slug="python")
cat_web = Category(name="Web Development", slug="web-development")
db.add_all([cat_python, cat_web])
db.flush()

# Courses
course1 = Course(
    title="Python for Beginners",
    description="A comprehensive introduction to Python programming. Learn variables, loops, functions, and object-oriented programming from scratch.",
    level="beginner",
    instructor_id=instructor.id,
    category_id=cat_python.id,
    thumbnail_url="https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800",
)
course2 = Course(
    title="FastAPI — Build REST APIs",
    description="Learn to build production-ready REST APIs with FastAPI, SQLAlchemy, and PostgreSQL. Covers auth, testing, and deployment.",
    level="intermediate",
    instructor_id=instructor.id,
    category_id=cat_web.id,
    thumbnail_url="https://images.unsplash.com/photo-1555066931-4365d14431b9?w=800",
)
db.add_all([course1, course2])
db.flush()

# Lessons for course1
lessons_c1 = [
    Lesson(course_id=course1.id, title="Introduction to Python", content="Python is a high-level, interpreted language known for its readability...", order=1, duration_minutes=15),
    Lesson(course_id=course1.id, title="Variables and Data Types", content="Python supports int, float, str, bool, list, dict, tuple, and set...", order=2, duration_minutes=20),
    Lesson(course_id=course1.id, title="Control Flow", content="Use if/elif/else and for/while loops to control program flow...", order=3, duration_minutes=25),
    Lesson(course_id=course1.id, title="Functions", content="Define reusable blocks of code with the def keyword...", order=4, duration_minutes=30),
]
db.add_all(lessons_c1)
db.flush()

# Enroll student in course1
enrollment = Enrollment(student_id=student.id, course_id=course1.id)
db.add(enrollment)

db.commit()
print("✅ Done! Demo credentials:")
print("   Instructor: instructor@learnflow.dev / instructor123")
print("   Student:    student@learnflow.dev / student123")
db.close()
