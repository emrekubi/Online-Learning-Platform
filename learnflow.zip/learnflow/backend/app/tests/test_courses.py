"""Tests for courses, lessons, enrollment, and progress."""
import pytest

from app.tests.conftest import auth_headers, create_user, get_token


# ── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def instructor_headers(client):
    create_user(client, email="instructor@example.com", role="instructor")
    token = get_token(client, email="instructor@example.com")
    return auth_headers(token)


@pytest.fixture
def student_headers(client):
    create_user(client, email="student@example.com", role="student")
    token = get_token(client, email="student@example.com")
    return auth_headers(token)


@pytest.fixture
def sample_course(client, instructor_headers):
    resp = client.post(
        "/api/v1/courses",
        json={"title": "Python Basics", "description": "Learn Python", "level": "beginner"},
        headers=instructor_headers,
    )
    assert resp.status_code == 201
    return resp.json()


# ── Course CRUD ──────────────────────────────────────────────────────────────

def test_list_courses_empty(client):
    resp = client.get("/api/v1/courses")
    assert resp.status_code == 200
    assert resp.json() == []


def test_create_course_as_instructor(client, instructor_headers):
    resp = client.post(
        "/api/v1/courses",
        json={"title": "FastAPI Deep Dive", "description": "Build REST APIs", "level": "intermediate"},
        headers=instructor_headers,
    )
    assert resp.status_code == 201
    assert resp.json()["title"] == "FastAPI Deep Dive"


def test_create_course_as_student_forbidden(client, student_headers):
    resp = client.post(
        "/api/v1/courses",
        json={"title": "Sneaky Course", "description": "...", "level": "beginner"},
        headers=student_headers,
    )
    assert resp.status_code == 403


def test_get_course_detail(client, sample_course):
    course_id = sample_course["id"]
    resp = client.get(f"/api/v1/courses/{course_id}")
    assert resp.status_code == 200
    assert resp.json()["title"] == "Python Basics"


def test_get_nonexistent_course(client):
    resp = client.get("/api/v1/courses/9999")
    assert resp.status_code == 404


def test_update_course(client, instructor_headers, sample_course):
    resp = client.patch(
        f"/api/v1/courses/{sample_course['id']}",
        json={"title": "Python Advanced"},
        headers=instructor_headers,
    )
    assert resp.status_code == 200
    assert resp.json()["title"] == "Python Advanced"


# ── Lessons ──────────────────────────────────────────────────────────────────

def test_add_lesson(client, instructor_headers, sample_course):
    resp = client.post(
        f"/api/v1/courses/{sample_course['id']}/lessons",
        json={"title": "Variables", "content": "Variables store data...", "order": 1},
        headers=instructor_headers,
    )
    assert resp.status_code == 201
    assert resp.json()["title"] == "Variables"


# ── Enrollment ───────────────────────────────────────────────────────────────

def test_enroll_student(client, student_headers, sample_course):
    resp = client.post(
        "/api/v1/enrollments",
        json={"course_id": sample_course["id"]},
        headers=student_headers,
    )
    assert resp.status_code == 201
    assert resp.json()["course_id"] == sample_course["id"]


def test_enroll_twice_is_error(client, student_headers, sample_course):
    client.post(
        "/api/v1/enrollments",
        json={"course_id": sample_course["id"]},
        headers=student_headers,
    )
    resp = client.post(
        "/api/v1/enrollments",
        json={"course_id": sample_course["id"]},
        headers=student_headers,
    )
    assert resp.status_code == 400


def test_my_enrollments(client, student_headers, sample_course):
    client.post(
        "/api/v1/enrollments",
        json={"course_id": sample_course["id"]},
        headers=student_headers,
    )
    resp = client.get("/api/v1/enrollments/me", headers=student_headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 1


# ── Progress ─────────────────────────────────────────────────────────────────

def test_complete_lesson_and_progress(client, instructor_headers, student_headers, sample_course):
    # Add a lesson
    lesson_resp = client.post(
        f"/api/v1/courses/{sample_course['id']}/lessons",
        json={"title": "Intro", "content": "Welcome!", "order": 1},
        headers=instructor_headers,
    )
    lesson_id = lesson_resp.json()["id"]

    # Enroll student
    client.post(
        "/api/v1/enrollments",
        json={"course_id": sample_course["id"]},
        headers=student_headers,
    )

    # Complete lesson
    resp = client.patch(f"/api/v1/progress/{lesson_id}", headers=student_headers)
    assert resp.status_code == 200

    # Check progress
    progress_resp = client.get(
        f"/api/v1/courses/{sample_course['id']}/progress",
        headers=student_headers,
    )
    assert progress_resp.status_code == 200
    data = progress_resp.json()
    assert data["completed_lessons"] == 1
    assert data["percent"] == 100.0


def test_complete_lesson_idempotent(client, instructor_headers, student_headers, sample_course):
    lesson_resp = client.post(
        f"/api/v1/courses/{sample_course['id']}/lessons",
        json={"title": "Intro", "content": "Welcome!", "order": 1},
        headers=instructor_headers,
    )
    lesson_id = lesson_resp.json()["id"]
    client.post(
        "/api/v1/enrollments",
        json={"course_id": sample_course["id"]},
        headers=student_headers,
    )
    client.patch(f"/api/v1/progress/{lesson_id}", headers=student_headers)
    resp = client.patch(f"/api/v1/progress/{lesson_id}", headers=student_headers)
    # Second call should still return 200
    assert resp.status_code == 200


def test_complete_lesson_without_enrollment(client, student_headers, instructor_headers, sample_course):
    lesson_resp = client.post(
        f"/api/v1/courses/{sample_course['id']}/lessons",
        json={"title": "Intro", "content": "Welcome!", "order": 1},
        headers=instructor_headers,
    )
    lesson_id = lesson_resp.json()["id"]
    resp = client.patch(f"/api/v1/progress/{lesson_id}", headers=student_headers)
    assert resp.status_code == 403
