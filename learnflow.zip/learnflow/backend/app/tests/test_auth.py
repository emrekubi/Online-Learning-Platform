"""Tests for authentication endpoints."""
import pytest


def test_register_success(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={
            "email": "alice@example.com",
            "full_name": "Alice",
            "password": "securepass",
            "role": "student",
        },
    )
    assert resp.status_code == 201
    data = resp.json()
    assert data["email"] == "alice@example.com"
    assert data["role"] == "student"
    assert "hashed_password" not in data


def test_register_duplicate_email(client):
    payload = {
        "email": "dup@example.com",
        "full_name": "Dup",
        "password": "securepass",
        "role": "student",
    }
    client.post("/api/v1/auth/register", json=payload)
    resp = client.post("/api/v1/auth/register", json=payload)
    assert resp.status_code == 400
    assert "already registered" in resp.json()["detail"].lower()


def test_register_short_password(client):
    resp = client.post(
        "/api/v1/auth/register",
        json={"email": "x@example.com", "full_name": "X", "password": "short"},
    )
    assert resp.status_code == 422


def test_login_success(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "bob@example.com", "full_name": "Bob", "password": "mypassword"},
    )
    resp = client.post(
        "/api/v1/auth/login",
        data={"username": "bob@example.com", "password": "mypassword"},
    )
    assert resp.status_code == 200
    assert "access_token" in resp.json()
    assert resp.json()["token_type"] == "bearer"


def test_login_wrong_password(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "carol@example.com", "full_name": "Carol", "password": "correct"},
    )
    resp = client.post(
        "/api/v1/auth/login",
        data={"username": "carol@example.com", "password": "wrong"},
    )
    assert resp.status_code == 401


def test_me_authenticated(client):
    client.post(
        "/api/v1/auth/register",
        json={"email": "dave@example.com", "full_name": "Dave", "password": "password123"},
    )
    token_resp = client.post(
        "/api/v1/auth/login",
        data={"username": "dave@example.com", "password": "password123"},
    )
    token = token_resp.json()["access_token"]
    resp = client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
    assert resp.status_code == 200
    assert resp.json()["email"] == "dave@example.com"


def test_me_unauthenticated(client):
    resp = client.get("/api/v1/auth/me")
    assert resp.status_code == 401
