from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from app.models.course import Course, Lesson
from app.models.enrollment import Enrollment, Progress
from app.models.user import User
from app.schemas.course import CourseCreate, CourseProgress, CourseUpdate, LessonCreate


# ── Courses ───────────────────────────────────────────────────────────────────

def list_courses(db: Session, skip: int = 0, limit: int = 20) -> list[Course]:
    return db.query(Course).offset(skip).limit(limit).all()


def get_course_or_404(db: Session, course_id: int) -> Course:
    course = db.query(Course).filter(Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Course not found")
    return course


def create_course(db: Session, payload: CourseCreate, instructor: User) -> Course:
    course = Course(**payload.model_dump(), instructor_id=instructor.id)
    db.add(course)
    db.commit()
    db.refresh(course)
    return course


def update_course(db: Session, course_id: int, payload: CourseUpdate, instructor: User) -> Course:
    course = get_course_or_404(db, course_id)
    if course.instructor_id != instructor.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your course")

    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(course, field, value)

    db.commit()
    db.refresh(course)
    return course


def delete_course(db: Session, course_id: int, instructor: User) -> None:
    course = get_course_or_404(db, course_id)
    if course.instructor_id != instructor.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your course")
    db.delete(course)
    db.commit()


# ── Lessons ───────────────────────────────────────────────────────────────────

def add_lesson(db: Session, course_id: int, payload: LessonCreate, instructor: User) -> Lesson:
    course = get_course_or_404(db, course_id)
    if course.instructor_id != instructor.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not your course")

    lesson = Lesson(course_id=course_id, **payload.model_dump())
    db.add(lesson)
    db.commit()
    db.refresh(lesson)
    return lesson


# ── Enrollment ────────────────────────────────────────────────────────────────

def enroll_student(db: Session, course_id: int, student: User) -> Enrollment:
    get_course_or_404(db, course_id)  # ensure course exists

    already = (
        db.query(Enrollment)
        .filter(Enrollment.student_id == student.id, Enrollment.course_id == course_id)
        .first()
    )
    if already:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Already enrolled"
        )

    enrollment = Enrollment(student_id=student.id, course_id=course_id)
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return enrollment


def get_my_enrollments(db: Session, student: User) -> list[Enrollment]:
    return db.query(Enrollment).filter(Enrollment.student_id == student.id).all()


# ── Progress ──────────────────────────────────────────────────────────────────

def complete_lesson(db: Session, lesson_id: int, student: User) -> Progress:
    lesson = db.query(Lesson).filter(Lesson.id == lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lesson not found")

    # Check enrolled
    enrolled = (
        db.query(Enrollment)
        .filter(
            Enrollment.student_id == student.id,
            Enrollment.course_id == lesson.course_id,
        )
        .first()
    )
    if not enrolled:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Not enrolled in this course"
        )

    existing = (
        db.query(Progress)
        .filter(Progress.student_id == student.id, Progress.lesson_id == lesson_id)
        .first()
    )
    if existing:
        return existing  # idempotent

    progress = Progress(student_id=student.id, lesson_id=lesson_id)
    db.add(progress)
    db.commit()
    db.refresh(progress)
    return progress


def get_course_progress(db: Session, course_id: int, student: User) -> CourseProgress:
    course = get_course_or_404(db, course_id)
    total = len(course.lessons)
    if total == 0:
        return CourseProgress(course_id=course_id, total_lessons=0, completed_lessons=0, percent=0)

    lesson_ids = [l.id for l in course.lessons]
    completed = (
        db.query(Progress)
        .filter(Progress.student_id == student.id, Progress.lesson_id.in_(lesson_ids))
        .count()
    )
    return CourseProgress(
        course_id=course_id,
        total_lessons=total,
        completed_lessons=completed,
        percent=round(completed / total * 100, 1),
    )
