from datetime import datetime
from typing import Optional

from pydantic import BaseModel


# ── Category ──────────────────────────────────────────────────────────────────

class CategoryRead(BaseModel):
    id: int
    name: str
    slug: str

    model_config = {"from_attributes": True}


# ── Lesson ────────────────────────────────────────────────────────────────────

class LessonCreate(BaseModel):
    title: str
    content: str
    video_url: Optional[str] = None
    order: int = 0
    duration_minutes: int = 10


class LessonRead(BaseModel):
    id: int
    title: str
    content: str
    video_url: Optional[str]
    order: int
    duration_minutes: int

    model_config = {"from_attributes": True}


class LessonSummary(BaseModel):
    """Lesson without full content — used in course listings."""
    id: int
    title: str
    order: int
    duration_minutes: int

    model_config = {"from_attributes": True}


# ── Course ────────────────────────────────────────────────────────────────────

class CourseCreate(BaseModel):
    title: str
    description: str
    thumbnail_url: Optional[str] = None
    level: str = "beginner"
    category_id: Optional[int] = None


class CourseUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    thumbnail_url: Optional[str] = None
    level: Optional[str] = None
    category_id: Optional[int] = None


class CourseRead(BaseModel):
    id: int
    title: str
    description: str
    thumbnail_url: Optional[str]
    level: str
    created_at: datetime
    instructor_id: int
    category: Optional[CategoryRead]
    lessons: list[LessonSummary] = []

    model_config = {"from_attributes": True}


class CourseSummary(BaseModel):
    """Lightweight course card for listings."""
    id: int
    title: str
    description: str
    thumbnail_url: Optional[str]
    level: str
    instructor_id: int

    model_config = {"from_attributes": True}


# ── Enrollment ────────────────────────────────────────────────────────────────

class EnrollmentCreate(BaseModel):
    course_id: int


class EnrollmentRead(BaseModel):
    id: int
    course_id: int
    student_id: int
    enrolled_at: datetime
    course: CourseSummary

    model_config = {"from_attributes": True}


# ── Progress ──────────────────────────────────────────────────────────────────

class ProgressRead(BaseModel):
    lesson_id: int
    completed_at: datetime

    model_config = {"from_attributes": True}


class CourseProgress(BaseModel):
    """Aggregated progress for one course."""
    course_id: int
    total_lessons: int
    completed_lessons: int
    percent: float
