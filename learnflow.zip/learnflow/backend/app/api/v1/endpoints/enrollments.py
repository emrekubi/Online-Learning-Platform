from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.course import CourseProgress, EnrollmentCreate, EnrollmentRead, ProgressRead
from app.services.course_service import (
    complete_lesson,
    enroll_student,
    get_course_progress,
    get_my_enrollments,
)

router = APIRouter(tags=["enrollments & progress"])


@router.post("/enrollments", response_model=EnrollmentRead, status_code=201)
def enroll(
    payload: EnrollmentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Enroll the current user in a course."""
    return enroll_student(db, payload.course_id, current_user)


@router.get("/enrollments/me", response_model=list[EnrollmentRead])
def my_enrollments(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List all courses the current user is enrolled in."""
    return get_my_enrollments(db, current_user)


@router.patch("/progress/{lesson_id}", response_model=ProgressRead)
def mark_complete(
    lesson_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Mark a lesson as completed. Idempotent."""
    return complete_lesson(db, lesson_id, current_user)


@router.get("/courses/{course_id}/progress", response_model=CourseProgress)
def course_progress(
    course_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get the current user's progress for a specific course."""
    return get_course_progress(db, course_id, current_user)
