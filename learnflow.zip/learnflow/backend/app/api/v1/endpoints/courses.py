from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_instructor, get_current_user
from app.db.session import get_db
from app.models.user import User
from app.schemas.course import CourseCreate, CourseRead, CourseSummary, CourseUpdate, LessonCreate, LessonRead
from app.services.course_service import (
    add_lesson,
    create_course,
    delete_course,
    get_course_or_404,
    list_courses,
    update_course,
)

router = APIRouter(prefix="/courses", tags=["courses"])


@router.get("", response_model=list[CourseSummary])
def get_courses(skip: int = 0, limit: int = 20, db: Session = Depends(get_db)):
    """List all available courses (public)."""
    return list_courses(db, skip=skip, limit=limit)


@router.get("/{course_id}", response_model=CourseRead)
def get_course(course_id: int, db: Session = Depends(get_db)):
    """Get a course with its lessons (public)."""
    return get_course_or_404(db, course_id)


@router.post("", response_model=CourseRead, status_code=201)
def create(
    payload: CourseCreate,
    db: Session = Depends(get_db),
    instructor: User = Depends(get_current_instructor),
):
    """Create a new course. Instructor role required."""
    return create_course(db, payload, instructor)


@router.patch("/{course_id}", response_model=CourseRead)
def update(
    course_id: int,
    payload: CourseUpdate,
    db: Session = Depends(get_db),
    instructor: User = Depends(get_current_instructor),
):
    """Update a course. Only the owning instructor can edit."""
    return update_course(db, course_id, payload, instructor)


@router.delete("/{course_id}", status_code=204)
def delete(
    course_id: int,
    db: Session = Depends(get_db),
    instructor: User = Depends(get_current_instructor),
):
    """Delete a course and its lessons."""
    delete_course(db, course_id, instructor)


@router.post("/{course_id}/lessons", response_model=LessonRead, status_code=201)
def create_lesson(
    course_id: int,
    payload: LessonCreate,
    db: Session = Depends(get_db),
    instructor: User = Depends(get_current_instructor),
):
    """Add a lesson to a course."""
    return add_lesson(db, course_id, payload, instructor)
